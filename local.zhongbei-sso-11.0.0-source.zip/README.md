# 中北大学统一身份认证

中北大学统一身份认证（CAS）接入**正方教务**的认证扩展：认证由本插件实现，学期、课表、成绩、成绩详情、考试与选课（轮次、课程、教学班、已选、选课、退课）继续使用 App 内置的新正方协议（`extends: "builtin.zf"`）。

## 真实入口（按实际响应核对）

| 用途 | 地址 |
| --- | --- |
| 统一身份认证（CAS） | `https://zhrz.nuc.edu.cn/cas/login` |
| 登录公钥 | `https://zhrz.nuc.edu.cn/cas/v2/getPubKey` |
| 验证码开关 | `https://zhrz.nuc.edu.cn/cas/v2/getKaptchaStatus` |
| 验证码图片 | `https://zhrz.nuc.edu.cn/cas/kaptcha` |
| 正方教务 | `https://zhjw.nuc.edu.cn/jwglxt/` |
| 学校登记的 CAS service | `http://zhjw.nuc.edu.cn/jwglxt/xtgl/index_initMenu.html` |

2026-10 实测（只做公开入口的 GET，未使用真实账号登录）：

- `GET https://zhjw.nuc.edu.cn/jwglxt/xtgl/index_initMenu.html` → **302** `https://zhrz.nuc.edu.cn/cas/login?service=http%3A%2F%2Fzhjw.nuc.edu.cn%2Fjwglxt%2Fxtgl%2Findex_initMenu.html`
- `GET https://zhrz.nuc.edu.cn/cas/login` → **200**，标题“统一身份认证平台”，表单 `#fm1`（`username`、`password`、`authcode`、`rememberMe`、`execution`、`_eventId`、`mobileCode`）
- `GET https://zhrz.nuc.edu.cn/cas/v2/getPubKey` → **200** `{"modulus":"…","exponent":"10001"}`（模数随会话变化）
- `GET https://zhrz.nuc.edu.cn/cas/v2/getKaptchaStatus` → **200** `false`（本次实测关闭）
- 登录脚本 `js/login/login.js`：`RSAUtils.encryptedString(key, 密码倒序)`，公钥来自 `v2/getPubKey`

## 为什么要改成扩展教务（本版的核心修正）

**旧版（6.0.0，`kind: native`）报“统一认证跳转与已声明服务不匹配”**：本校 CAS 只登记了 **http** 形态的 service 回调，而 `authScope`（固定登录地址与登记回调）与 `upgradeHttpRedirects`（把 https 响应指向的默认端口 http 回调改用 https，**不改写**原 service 参数）只属于 `sdk.http` 的教务认证请求。SDK 明确把这两项从原生插件的请求里去掉：

```ts
// sdk/index.d.ts
export interface NativeHttpRequest extends Omit<HttpRequest, 'cookieHeader' | 'upgradeHttpRedirects' | 'sameOriginReferer' | 'authScope'> {
```

`network.request` 的能力输入里也没有这些字段。因此 `kind: native` 无法为“只登记 http service 的 CAS”固定回调，也无法升级回调请求。套件内真实学校先例 [盐城工学院](../../ycit/README.md) 正是同一情形（“学校 CAS 只注册了 HTTP service；将 service 参数改为 https 会被学校拒绝”），其做法是 `kind: "extension"` + `upgradeHttpRedirects`。本版照此把插件改为：

- `kind: "extension"`、`extends: "builtin.zf"`，只声明并实现 `auth` 组（4 项）；
- 认证请求带 `authScope: {loginUrl, serviceUrl}` 与 `upgradeHttpRedirects: true`；
- `serviceUrl` 保持学校登记的 **http** 形态（改成 https 会被学校拒绝），全部请求实际以 HTTPS 发出；
- 学业查询、选课继续由内置新正方协议提供（未在本插件中重复实现）。

## 登录流程（与学校脚本一致）

```
GET  https://zhrz.nuc.edu.cn/cas/login?service=<登记 http 回调>   取 #fm1 的 execution
GET  https://zhrz.nuc.edu.cn/cas/v2/getPubKey                     本次会话的公钥
GET  https://zhrz.nuc.edu.cn/cas/v2/getKaptchaStatus              是否需要验证码
GET  https://zhrz.nuc.edu.cn/cas/kaptcha                          需要验证码时（返回 base64）
POST https://zhrz.nuc.edu.cn/cas/login?service=<登记 http 回调>   username/password/authcode/_eventId=submit
      password = 倒序密码 + 教科书式 RSA（jsbn 16 位小端块，非 PKCS#1）
302  →  学校登记的 http 回调 + ?ticket=ST-…
GET  https://zhjw.nuc.edu.cn/jwglxt/xtgl/index_cxYhxxIndex.html?gnmkdm=index   核对教务身份
```

加密实现说明：学校 `security.js` 的 `RSAUtils.encryptedString` 是先补零再做**教科书式 RSA**（`powMod`，无 PKCS#1 填充），与宿主 `crypto.rsaEncrypt`（PKCS#1 v1.5）不同。本插件用 BigInt 自行做模幂，并已把该函数在本地沙箱中执行后对拍：同一公钥与密码下密文**逐字节一致**。

## 清单

| 项目 | 取值 |
| --- | --- |
| 插件 ID / 版本 | `local.zhongbei-sso` / **7.0.0** |
| `kind` / `extends` | `extension` / `builtin.zf` |
| 能力（4） | `auth.start`、`auth.resume`、`auth.refreshCaptcha`、`auth.validate` |
| 权限 / 要求 | `network.request@2`（`sdk.http` 认证路径） |
| 学校 | `school.protocol = https`、`domain = zhjw.nuc.edu.cn`、`basePath = /jwglxt`、`academicSystem = zf` |
| `matches` | `zhjw.nuc.edu.cn` + `/jwglxt`（https） |
| 网络范围 | `https://zhrz.nuc.edu.cn/cas`（GET/POST，auth）；`https://zhjw.nuc.edu.cn/jwglxt`（GET/POST，auth+query+mutation）；`http://zhjw.nuc.edu.cn/jwglxt/xtgl/index_initMenu.html`（GET，auth，唯一的 http 声明，仅学校登记的 service 回调） |
| `features` | 见清单，功能标签与 `description` 分开维护 |

`study.calendar` 未声明：内置新正方协议不提供该方法，因此不声明、也不猜测。`selection.filters` 为可选项，本插件不声明。

## 命令与实际结果（全部退出码 0）

| 命令 | 实际输出 |
| --- | --- |
| `check` | `Checked local.zhongbei-sso (4 capabilities)` |
| `test` | **`Passed 11 fixtures`** |
| `scenario` | `Passed 0 scenario steps`（无 `ui`/`task` 处理器） |
| `submit-check` / `pack` | `packed dist\local.zhongbei-sso-7.0.0.eduplugin` |
| `source-zip` | `dist\local.zhongbei-sso-7.0.0-source.zip` |

11 个样本覆盖：

1. CAS 拒绝密码 → `INVALID_CREDENTIALS`（并断言提交的密文是固定向量，证明加密变换正确）；
2. 验证码开关 `true` → 返回验证码图片与续接；
3. `refreshCaptcha` 复用同一 pending 并带时间戳取新图；
4. 验证码提交 → 302 → 登记回调 → 核对教务身份（断言 `authScope` 与 `upgradeHttpRedirects`）；
5. **学校改换 service 回调时整条跳转以 `UNTRUSTED_URL` 拒绝**（直接覆盖“统一认证跳转与已声明服务不匹配”）；
6. 需要二次认证 → 交接学校网页（`webLogin` + `completionUrl`）；
7. 网页验证未完成 → `WEB_LOGIN_REQUIRED`；
8. 网页验证完成 → 重新核对教务身份并返回 `authenticated`；
9. 教务会话失效 → `SESSION_EXPIRED`；
10. 已登录 → 返回教务身份；
11. 登录页结构变化 → `PAGE_CHANGED`（不猜测、不伪装成功）。

继承路径另外单独核对过：把扩展的 `school` 交给内置新正方协议后，`study.terms` 使用
`https://zhjw.nuc.edu.cn/jwglxt` 请求课表筛选页与成绩筛选页（`kbcx/xskbcx_cxXsKb.html?gnmkdm=N253508`、
`cjcx/cjcx_cxDgXscj.html?gnmkdm=N305005`）并解析出学期，返回契约校验通过。该核对不在 11 个样本内。

## 已知修正

- **7.0.0**：从 `kind: native` 改为 `kind: extension`（`extends: builtin.zf`）。原生插件的 `network.request` 不提供 `authScope`/`upgradeHttpRedirects`，无法固定学校登记的 http service 回调，宿主因此以 `UNTRUSTED_URL`（统一认证跳转与已声明服务不匹配）拒绝整条登录链。认证改为走 `sdk.http`，并在 CAS 回 302 时显式请求登记回调；同时改为请求带 `service` 的登录页，使 `execution` 与回调绑定。
- **6.0.0 / 5.0.0 / 4.1.0 / 4.0.0**：均为 `kind: native` 的尝试（含把 `serviceUrl` 写成 http、把配置注入提前到协议库导入之前）。这些改动方向正确，但 native 路径缺少上述两个请求字段，无法解决回调判定问题；本版用扩展教务路径替代。
- **3.0.0**：修正入口地址（早期误用未启用的 `sfzt.nuc.edu.cn` / `ehall.nuc.edu.cn`），正确入口是 `zhrz` + `zhjw`。

## 未验证项（必须与样本结果分开报告）

- **真实账号登录未通过**：用任务提供的账号直接对 `POST /cas/login` 实测，服务器返回页面内提示“用户名或密码错误”（`#msg`）。同一响应与不存在的账号、错误密码完全一致，因此无法从响应区分“密码不符”与“账号不存在”。**样本测试、浏览器模拟、设备测试与真实学校验收必须分开报告**；本插件的离线样本通过**不代表**学校实测通过。
- 未取得登录成功后的真实 302 与教务身份页，因此 `serviceUrl`、回调路径与身份页解析只在公开 302 与合成样本上核对过。
- 登录后的 study / selection 真实数据（学期、课表、成绩、考试、轮次、教学班、已选）未验收。
- `selection.select` / `selection.drop` 的真实提交结果未验收（写入须逐次确认，`RESULT_UNKNOWN` 不自动重试）。
- 真机验收（Android API 24/32/35）、WebView 与大字体未做。
- `upgradeHttpRedirects` 把 http 回调提升为 HTTPS 的实际行为由宿主执行。离线样本按 `authScope` 的契约用**登记 http 回调**校验（把回调换成 https 会被 `checkAuthScope` 拒绝），因此样本**不覆盖**宿主的升级步骤本身。

## 本地安装与签名

- 调试 App + 开发者模式：导入 `dist/local.zhongbei-sso-7.0.0.eduplugin`（未签名；开发模式允许未签名包）。
- 需要用本地测试密钥签名时：`node cli/release.mjs sign-package dist/local.zhongbei-sso-7.0.0.eduplugin .local/signing/private.pem <输出> local-test`，并在调试 App 高级工具填入配套 `.local/signing/public.json`；私钥不得外发。
- 正式上架必须用管理页“离线签名”材料中的信任私钥，本地测试密钥不能用于上架。

## 维护与投稿

- 许可证 GPL-3.0-only，随包提供 `LICENSE`；`protocol-lock.json` 与 `src/vendor/` 下的 3.2.1 协议文件是上一版原生实现留下的固定依赖，本版不再引用它们（认证走 `sdk.http`，学业查询继承 `builtin.zf`），保留它们只为不改动既有锁定摘要。
- 本插件为本地新建并自行改版（未使用 `import-source`），因此目录内**没有** `source-origin.json`，也没有原作者源码可保留；投稿时按“独立衍生”或“修复原插件”入口二选一，并如实填写来源。
- 投稿前替换 `maintainers` 占位名称并复核 `verifiedScope`；升级保留 ID `local.zhongbei-sso` 并递增版本。
- 本插件未修改公共协议库（`protocols/`），只声明继承 `builtin.zf`；如需修改公共库，必须重新计算 `protocol-lock.json` 摘要并回归全部消费者。
- 源码包不包含账号、密码、Cookie、验证码或真实学生记录；样本全部为合成数据。
