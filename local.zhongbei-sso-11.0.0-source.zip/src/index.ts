import type {AcademicPlugin, AuthState, Context, ErrorCode, HostSdk, Result} from '../../../sdk/index';
import academic from './vendor/protocols/3.2.1/zf/index';
const {auth, study, selection} = academic;

// 中北大学：CAS（zhrz.nuc.edu.cn）→ 正方教务（zhjw.nuc.edu.cn/jwglxt）。
//
// 登录采用「网页登录交接」：插件不提交密码，交给宿主打开 WebView，用户在浏览器里登录，
// 浏览器自行处理学校 http service → https 回调的 301 链（这是唯一能登录通的方式）。
// 宿主取回该次会话 Cookie 后再做只读身份确认。
//
// 关键：WebView 入口用学校的 http service（zhjw 注册的真实 service），
// 浏览器走 http→https 301 最终落在 https://zhjw.../index_initMenu.html（即 completionUrl）。
const academicEntry = 'https://zhjw.nuc.edu.cn/jwglxt/xtgl/index_initMenu.html';
const webEntry = 'https://zhrz.nuc.edu.cn/cas/login?service=' + encodeURIComponent('http://zhjw.nuc.edu.cn/jwglxt/xtgl/index_initMenu.html');
const pendingTtlMs = 20 * 60_000;

const ok = <T>(data: T): Result<T> => ({ok: true, data});
function fail(code: ErrorCode, message: string): never { throw Object.assign(new Error(message), {code}); }
interface Pending {id: string; expires: number; account: string}

function webResult(p: Pending): Result<AuthState> {
  return ok({status: 'webLogin', continuationId: p.id, url: webEntry, completionUrl: academicEntry});
}
async function beginWebLogin(s: HostSdk, account: string): Promise<Result<AuthState>> {
  const p: Pending = {id: Date.now().toString(36) + '-' + Math.random().toString(36).slice(2), expires: Date.now() + pendingTtlMs, account};
  await s.state.set('pending', p);
  return webResult(p);
}
async function requirePending(s: HostSdk, id: string): Promise<Pending> {
  const saved = await s.state.get<Pending>('pending');
  if (saved && !(saved.expires > Date.now())) await s.state.remove('pending');
  if (!saved || !id || saved.id !== id || !(saved.expires > Date.now())) {
    fail('SESSION_EXPIRED', '中北大学统一身份认证的本次网页登录已过期，请重新登录');
  }
  return saved;
}
async function confirmIdentity(s: HostSdk, c: Context, account: string): Promise<Result<AuthState>> {
  await s.state.set('protocol:username', account);
  await s.state.remove('protocol:login');
  const result = await auth.validate({}, c, s);
  await s.state.remove('pending');
  return result;
}

const authGroup: AcademicPlugin['auth'] = {
  start: async (args, _c, s) => {
    const account = (args.username || '').trim();
    if (!account) fail('INVALID_CREDENTIALS', '请输入中北大学统一身份认证账号');
    if (!args.password) fail('INVALID_CREDENTIALS', '请输入中北大学统一身份认证密码');
    await s.state.remove('pending');
    return beginWebLogin(s, account);
  },
  resume: async (args, c, s) => {
    const p = await requirePending(s, args.continuationId);
    if (!args.webLoginCompleted) fail('WEB_LOGIN_REQUIRED', '请先在中北大学统一身份认证页面完成登录');
    return confirmIdentity(s, c, p.account);
  },
  refreshCaptcha: async (args, _c, s) => webResult(await requirePending(s, args.continuationId)),
  validate: (_args, c, s) => auth.validate({}, c, s)
};

const plugin = {
  auth: authGroup,
  study,
  selection
} satisfies AcademicPlugin;

export default plugin;
